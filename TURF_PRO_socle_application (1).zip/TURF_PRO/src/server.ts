import 'dotenv/config';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import fastifyStatic from '@fastify/static';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import jwt from '@fastify/jwt';
import bcrypt from 'bcryptjs';
import { PrismaClient, PredictionStatus, Role } from '@prisma/client';
import { z } from 'zod';

const app = Fastify({ logger: true, bodyLimit: 1024 * 1024 });
const db = new PrismaClient();
const port = Number(process.env.PORT || 3000);
const __dirname = dirname(fileURLToPath(import.meta.url));
await app.register(fastifyStatic, { root: join(__dirname, '../public') });
await app.register(helmet);
await app.register(cors, { origin: process.env.CORS_ORIGIN?.split(',') ?? false });
await app.register(rateLimit, { max: 100, timeWindow: '1 minute' });
await app.register(jwt, { secret: process.env.JWT_SECRET || 'development-only-change-this-secret' });

function requireAuth(roles?: Role[]) {
  return async (req: any, reply: any) => {
    try { await req.jwtVerify(); }
    catch { return reply.code(401).send({ error: 'Authentification requise' }); }
    if (roles && !roles.includes(req.user.role)) return reply.code(403).send({ error: 'Accès interdit' });
  };
}
app.get('/health', async () => ({ ok: true, service: 'TURF PRO API', mode: process.env.NODE_ENV || 'development' }));

app.post('/auth/login', async (req, reply) => {
  const parsed = z.object({ email: z.string().email(), password: z.string().min(8) }).safeParse(req.body);
  if (!parsed.success) return reply.code(400).send({ error: 'Identifiants invalides' });
  const user = await db.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
  if (!user || !user.active || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return reply.code(401).send({ error: 'Identifiants incorrects' });
  const token = app.jwt.sign({ sub: user.id, role: user.role, email: user.email }, { expiresIn: '8h' });
  return { token, user: { id: user.id, email: user.email, role: user.role } };
});

app.get('/races', async (req: any) => {
  const date = typeof req.query?.date === 'string' ? new Date(req.query.date) : new Date();
  const from = new Date(date); from.setHours(0,0,0,0);
  const to = new Date(from); to.setDate(to.getDate()+1);
  return db.race.findMany({ where: { startsAt: { gte: from, lt: to }, status: { not: 'DATA_QUARANTINED' } }, include: { runners: true }, orderBy: { startsAt: 'asc' } });
});

app.get('/admin/ai/overview', { preHandler: requireAuth([Role.SUPER_ADMIN, Role.REVIEWER, Role.ANALYST]) }, async () => {
  const [pending, races, latestSync] = await Promise.all([
    db.prediction.count({ where: { status: PredictionStatus.PENDING_REVIEW } }),
    db.race.count({ where: { startsAt: { gte: new Date() } } }),
    db.providerSyncRun.findFirst({ orderBy: { startedAt: 'desc' } })
  ]);
  return { pendingPredictions: pending, upcomingRaces: races, latestSync };
});
app.get('/admin/ai/predictions', { preHandler: requireAuth([Role.SUPER_ADMIN, Role.REVIEWER, Role.ANALYST]) }, async (req: any) => {
  const status = Object.values(PredictionStatus).includes(req.query?.status) ? req.query.status : PredictionStatus.PENDING_REVIEW;
  return db.prediction.findMany({ where: { status }, include: { race: { include: { runners: true } } }, orderBy: { generatedAt: 'asc' } });
});
const reviewSchema = z.object({ reason: z.string().max(1000).optional() });
async function decidePrediction(req: any, reply: any, decision: 'approve'|'reject'|'revise') {
  const { id } = req.params;
  const body = reviewSchema.safeParse(req.body ?? {});
  if (!body.success) return reply.code(400).send({ error: 'Motif invalide' });
  const prediction = await db.prediction.findUnique({ where: { id }, include: { race: { include: { runners: true } } } });
  if (!prediction) return reply.code(404).send({ error: 'Pronostic introuvable' });
  if (prediction.status !== PredictionStatus.PENDING_REVIEW && prediction.status !== PredictionStatus.REVIEW_REQUIRED) return reply.code(409).send({ error: 'Ce pronostic ne peut plus être validé dans son état actuel' });
  if (decision === 'approve' && (prediction.race.runners.length < 2 || prediction.race.runners.every(r => r.isNonRunner))) return reply.code(409).send({ error: 'Partants insuffisants ou non confirmés' });
  const next = decision === 'approve' ? PredictionStatus.APPROVED : decision === 'reject' ? PredictionStatus.REJECTED : PredictionStatus.REVISION_REQUESTED;
  const actorId = req.user.sub;
  const updated = await db.$transaction(async tx => {
    const p = await tx.prediction.update({ where: { id }, data: { status: next, ...(decision === 'approve' ? { approvedAt: new Date() } : {}) } });
    await tx.review.create({ data: { predictionId: id, userId: actorId, decision, reason: body.data.reason } });
    await tx.auditLog.create({ data: { actorId, action: `prediction.${decision}`, entityType: 'Prediction', entityId: id, details: { reason: body.data.reason ?? null } } });
    return p;
  });
  return updated;
}
app.post('/admin/ai/predictions/:id/approve', { preHandler: requireAuth([Role.SUPER_ADMIN, Role.REVIEWER]) }, (req, reply) => decidePrediction(req, reply, 'approve'));
app.post('/admin/ai/predictions/:id/reject', { preHandler: requireAuth([Role.SUPER_ADMIN, Role.REVIEWER]) }, (req, reply) => decidePrediction(req, reply, 'reject'));
app.post('/admin/ai/predictions/:id/request-revision', { preHandler: requireAuth([Role.SUPER_ADMIN, Role.REVIEWER, Role.ANALYST]) }, (req, reply) => decidePrediction(req, reply, 'revise'));

// Aucun fournisseur de courses ni passerelle de paiement n'est activé par défaut.
app.post('/integrations/horse-racing/:provider/sync', { preHandler: requireAuth([Role.SUPER_ADMIN]) }, async (req: any, reply) => {
  if (!process.env.HORSE_PROVIDER_API_KEY || !process.env.HORSE_PROVIDER_BASE_URL) return reply.code(503).send({ error: 'Connecteur inactif : contrat et clés fournisseur requis' });
  return reply.code(501).send({ error: 'Adaptateur fournisseur à implémenter après validation de son API et de sa licence' });
});
app.post('/payments/checkout', { preHandler: requireAuth() }, async (_req, reply) => reply.code(503).send({ error: 'Paiement désactivé tant que les identifiants FedaPay et le webhook sécurisé ne sont pas configurés' }));
app.post('/webhooks/fedapay', async (_req, reply) => reply.code(503).send({ error: 'Webhook non activé : signature fournisseur à configurer avant encaissement' }));

app.addHook('onClose', async () => db.$disconnect());
try { await app.listen({ port, host: '0.0.0.0' }); }
catch (err) { app.log.error(err); process.exit(1); }
