# TURF PRO — socle applicatif

Ce dépôt transforme le prototype HTML en socle backend avec PostgreSQL, authentification JWT, rôles, file de validation IA, audit et règles d'accès serveur. Le prototype est conservé dans `public/demo.html`.

## Important avant toute ouverture au public

Ce dépôt est un **socle de développement**, pas encore une production commerciale. Aucun flux hippique réel, aucune génération IA réelle et aucun encaissement ne sont activés par défaut. Il ne faut pas annoncer de courses ni de résultats fictifs. Le connecteur hippique doit être branché après vérification de la licence de redistribution et des pays couverts. FedaPay doit être configuré avec ses secrets et un webhook vérifié avant d'accepter le moindre paiement.

## Démarrage local

Prérequis : Node.js 22+, PostgreSQL 15+.

```bash
cp .env.example .env
# Modifier DATABASE_URL et JWT_SECRET dans .env
npm install
npx prisma generate
npx prisma migrate dev --name initial
npm run dev
```

API : `http://localhost:3000/health`  
Prototype visuel : `http://localhost:3000/demo.html`.

## Routes principales

- `POST /auth/login`
- `GET /races?date=2026-11-20`
- `GET /admin/ai/overview`
- `GET /admin/ai/predictions?status=PENDING_REVIEW`
- `POST /admin/ai/predictions/:id/approve`
- `POST /admin/ai/predictions/:id/reject`
- `POST /admin/ai/predictions/:id/request-revision`
- `POST /integrations/horse-racing/:provider/sync` (bloqué tant que le fournisseur n'est pas configuré)
- `POST /payments/checkout` et `POST /webhooks/fedapay` (bloqués tant que l'intégration de paiement n'est pas sécurisée)

Les routes `/admin` exigent un JWT et un rôle autorisé. Le compte super-admin doit être créé via une procédure d'amorçage sécurisée avant le déploiement ; ne pas utiliser de mot de passe par défaut.

## Prochaines étapes techniques obligatoires

1. Créer un script d'amorçage super-admin avec mot de passe haché et secrets d'environnement.
2. Sélectionner et contractualiser un fournisseur de données hippiques couvrant les territoires visés ; implémenter son adaptateur documenté.
3. Implémenter le moteur statistique et le fournisseur IA, sortie structurée validée, et blocage sur données incomplètes.
4. Connecter FedaPay côté serveur, vérifier signatures/transactions et rendre le traitement webhook idempotent.
5. Construire l'interface React/Next.js publique et Back-Office au-dessus de l'API.
6. Ajouter tests automatisés, sauvegardes, monitoring, politique de confidentialité et conformité locale/internationale.
7. Déployer avec HTTPS, base managée, secrets protégés et domaine.

Les tarifs métier repris du prototype sont documentés dans `docs/REGLES_METIER.md`.
