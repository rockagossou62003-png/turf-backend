# TURF PRO — socle applicatif v0.1

Base initiale du produit web TURF PRO, issue du prototype HTML et des règles métier existantes.

## Livré
- Application Next.js / TypeScript.
- Page publique responsive et tarifs initiaux.
- Prévisualisation du Back-Office IA.
- Endpoint de santé `/api/health`.
- Schéma PostgreSQL/Prisma : comptes, rôles, courses, partants, pronostics, validations, produits, commandes, droits et audit.
- Docker Compose PostgreSQL + Redis.
- Ancien prototype conservé dans `legacy/`.

## Démarrage local
Prérequis : Node.js 22+ et Docker Desktop.

```bash
cp apps/web/.env.example apps/web/.env
docker compose up -d
npm install
npm run db:generate
npm run db:push
npm run dev
```
Site : http://localhost:3000 — Back-Office de prévisualisation : http://localhost:3000/admin

## Limites actuelles — ne pas utiliser en production
Aucune authentification réelle, aucun flux hippique réel, aucune action d'approbation serveur, aucun paiement FedaPay. Le Back-Office est une maquette visuelle non protégée. Le mode `demo` ne doit jamais être présenté comme un flux réel.

## Suite
1. Authentification et rôles serveur.
2. Contrat fournisseur autorisant l'affichage et l'usage des données pour les analyses.
3. Connecteur, synchronisation et contrôle qualité.
4. Moteur d'analyse et file de validation.
5. Publication sécurisée et audit.
6. FedaPay serveur et webhook vérifié.
7. Tests, sécurité, sauvegardes et déploiement.

Les secrets restent dans les variables d'environnement serveur.
