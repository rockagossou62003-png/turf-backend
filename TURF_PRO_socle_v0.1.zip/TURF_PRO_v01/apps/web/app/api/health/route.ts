import {NextResponse} from "next/server";
export async function GET(){return NextResponse.json({app:"TURF PRO",status:"ok",environment:process.env.NODE_ENV??"development",racingProvider:process.env.HORSE_RACING_PROVIDER??"not-configured",note:"Health check only. No live racing feed or payment provider is connected."})}
