import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "TURF PRO — Pronostics hippiques", description: "Analyses et pronostics hippiques avec validation éditoriale." };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
