# État initial — TURF PRO

## Décisions métier
Plateforme éditoriale qui vend l'accès à des contenus d'analyse et de pronostics ; elle ne reçoit pas de mises et ne promet pas de gains. Les pronostics IA restent en attente d'une validation humaine. Aucune course, aucun partant, aucune cote et aucun résultat ne doivent être inventés.

## Tarifs initiaux
Gratuit 0 XOF ; Couplé 500 XOF par combinaison ; Trio désordre 2 500 XOF ; Trio ordre 8 000 XOF ; Quinté 7 chevaux 5 000 XOF ; VIP 24 h 10 000 XOF ; VIP 7 jours 34 680 XOF. Le VIP mensuel à 80 000 XOF est à confirmer.

## Données
Les conditions publiques de certains fournisseurs limitent la redistribution, la revente de données brutes ou l'usage dans un service de tips. Un accord écrit doit préciser l'usage TURF PRO avant activation en production.

## Sécurité
Droits d'accès vérifiés côté serveur ; paiement confirmé uniquement par webhook signé et idempotent ; changements critiques de partants/horaires pouvant suspendre un pronostic ; audit des actions sensibles.
